package sobrecargapokemon;

import entidades.*;//* :importa todas las clases de entidades

public class SobrecargaPokemon {

    public static void main(String[] args) {
        
        Pikachu p = new Pikachu();
        Pikachu w = new Pikachu();
        Charmander n = new Charmander();
        
        Entrenador e = new Entrenador("Ingrid");
        
        e.CapturarPokemon(p, "Luna ");
        e.CapturarPokemon(w, "Sol ");
        e.CapturarPokemon(n, "Estrella");
        
        System.out.println(e.toString());
    }
    
}
