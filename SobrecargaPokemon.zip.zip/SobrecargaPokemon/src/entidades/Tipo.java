package entidades;

public class Tipo {
    
    private String nombre;
    
    public Tipo(String n){
        nombre = n;
    }

    public String getNombre() {
        return nombre;
    }
    
}
