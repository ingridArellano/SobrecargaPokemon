package entidades;

import java.util.ArrayList;

public class Entrenador {
    
    private String nombre;
    private ArrayList<Pokemon> pokemonesAtrapados;
    
    public Entrenador(String n){
        nombre =n;
        pokemonesAtrapados = new ArrayList<>();
        
    }

    public String getNombre() {
        return nombre;
    }

    public ArrayList<Pokemon> getPokemonesAtrapados() {
        return pokemonesAtrapados;
    }
    
    public void CapturarPokemon(Pokemon p, String nombre){
        p.setNombre(nombre);
        pokemonesAtrapados.add(p);
    }
     

    @Override
    public String toString() {
        return "Entrenador{" + "nombre=" + nombre + ", pokemonesAtrapados=" + MostrarPokemonesAtrapados() + '}';
    }
    
    public String MostrarPokemonesAtrapados(){
        String resultado = "";
        
        for(Pokemon p : pokemonesAtrapados){
            resultado += p.getNombre()+ "";
        }
        return resultado.trim();
    }
}
