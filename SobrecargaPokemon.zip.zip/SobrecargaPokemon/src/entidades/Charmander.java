package entidades;

public class Charmander extends Pokemon {
    
    public Charmander(){
        
        tipos.add(new Tipo("Fuego"));
        
    } 
    
    @Override //Sobreescribe a la herencia(un comportamineto heredado es sobreescrito por el hijo)
    public void SubirNivel(){
        nivel += 1;
        ataque += 6;
        defensa += 4;
        vida += 21;
        velocidad += 2;
    }
    
}
