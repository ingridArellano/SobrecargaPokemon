package entidades;

import java.util.ArrayList;

public class Pokemon {
    
    protected String nombre;
    protected int vida;
    protected int ataque;
    protected int velocidad;
    protected int defensa;

    @Override
    public String toString() {
        return "Pokemon{" + "nombre=" + nombre + ", vida=" + vida + ", ataque=" + ataque + ", velocidad=" + velocidad + ", defensa=" + defensa + ", nivel=" + nivel + ", tipos=" + MostrarTipos() + '}';
    }
    protected int nivel;
    protected ArrayList<Tipo> tipos;
    
    public Pokemon(){
        nivel = 1;
        velocidad = 1;
        defensa = 1;
        ataque = 1;
        vida = 1;
        tipos = new ArrayList<>();//Iniciando un ArrayList vacío
    }
    
    //public void SubirNivel() :Firma
    //Sobrecarga:Cuando existen varias firmas iguales pero con diferentes parametros
    public void SubirNivel(){
        nivel += 1;
        vida += 20;
        ataque += 5;
        defensa += 5;
        velocidad += 2;
    }
    
    public void SubirNivel(int cantidad){
        
        nivel += 1*cantidad;
        vida += 20*cantidad;
        ataque += 5*cantidad;
        defensa += 5*cantidad;
        velocidad += 2*cantidad;
        
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public int getVida() {
        return vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public int getNivel() {
        return nivel;
    }

    public int getDefensa() {
        return defensa;
    }
    
    public ArrayList<Tipo> getTipos() {
        return tipos;
    }

    public String MostrarTipos(){
        String resultado = "";
        
        for(Tipo tipo : tipos){
            resultado += tipo.getNombre()+ "";
        }
        return resultado.trim();//trim = corta los especios en blanco del inicio y final(Aplana la lista)
    }
    
}
