package entidades;

public class Pikachu extends Pokemon {
   
    public Pikachu(){
        
        tipos.add(new Tipo("Eléctrico"));//añadiendo una instancia de tipo eléctrico
        
    }
    
    @Override //Sobreescribe a la herencia(un comportamineto heredado es sobreescrito por el hijo)
    public void SubirNivel(){
        nivel += 1;
        ataque += 6;
        defensa += 4;
        vida += 21;
        velocidad += 2;
    }
    
}
